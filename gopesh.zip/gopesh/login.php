<?php
	include 'dbh1.php';
$email=$_POST['email'];
$pass=$_POST['pass'];
$sql="select * from book where email='$email' and password='$pass'";
$result=$conn->query($sql);
if($result->num_rows>0)
{
		header('location:enterBlogPost.php');
}
?>