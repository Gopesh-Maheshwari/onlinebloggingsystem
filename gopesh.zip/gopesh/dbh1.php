<?php

$conn= new mysqli("localhost","root","gsssv","class");


?>