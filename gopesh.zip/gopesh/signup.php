<?php
	include 'dbh1.php';
	$name=$_POST["name"];
$email=$_POST["email"];
$pass=$_POST["pass"];
$date=$_POST["date"];
$month=$_POST["month"];
$year=$_POST["year"];
$gender=$_POST["gender"];
$sql="insert into book(name,email,password,date,month,year,gender) VALUES ('$name','$email','$pass','$date','$monh','$year','$gender')";
$conn->query($sql);
echo ' Data Entered';
header('location:index.php');
?>